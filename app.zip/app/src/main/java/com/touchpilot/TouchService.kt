package com.touchpilot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.*
import android.widget.*
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class TouchService : Service() {
    private lateinit var windowManager: WindowManager
    private val groups = mutableListOf<Group>()
    private var selectedGroup = 0
    private var captureGroup = 0
    private var selectorRow: LinearLayout? = null
    private var panel: View? = null
    private var activeGroup: Group? = null   // the group whose gesture is running right now
    private var runToken = 0                 // invalidates callbacks that belong to an older run
    private var watchdog: Runnable? = null
    private var capWarned = false
    private var outsideTarget = false        // the selected app is not in front: buttons hidden, nothing is tapped
    private var busy = false
    private var repeating = false
    private var pressMode = 0   // 0 = tap, 1 = long press, 2 = very fast repeat
    private var together = true // true = one multi-touch gesture, false = quick one-after-another
    private var logoView: View? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlaysHidden = false
    private var buttonsHidden = false        // user choice: hide the look of T buttons/copies, keep the floating panel
    private var quickColumn: LinearLayout? = null
    private var legendView: TextView? = null
    private var hideValueView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val notificationId = 91

    // One group = one T button plus its own copies. Pressing a T taps only its own group.
    private class Group(var colorIdx: Int) {
        var tView: View? = null
        val views = mutableListOf<View>()
        val coords = mutableListOf<Pair<Float, Float>>()
    }

    private fun colorOf(g: Group) = GROUP_COLORS[g.colorIdx % GROUP_COLORS.size]

    private fun chipViews(): List<View> = groups.flatMap { listOfNotNull(it.tView) + it.views }

    private fun allOverlays(): List<View> = listOfNotNull(panel) + chipViews()

    private fun tSizePx() = dp(56)

    // Where the T of the n-th group starts (fractions of the screen).
    private fun defaultTPos(pos: Int): Pair<Float, Float> =
        if (pos == 0) 0.8f to 0.5f
        else (0.85f - 0.18f * (pos / 4)) to (0.25f + 0.17f * (pos % 4))

    private fun chipAlpha() = if (overlaysHidden || buttonsHidden || outsideTarget) 0f else 1f

    // Only the chips of the group that is running ignore touches (fewer window updates = smoother screen).
    private fun chipsTouchable(g: Group) = !(overlaysHidden || buttonsHidden || outsideTarget || g === activeGroup)

    // Naming: main buttons are T1..T5 (solid circles). Copies are dashed "ghost" circles that show
    // the owning T in small text on top and their own number below, e.g. "T2 / 3".
    private fun mainLabel(gi: Int) = "T${gi + 1}"

    private fun copyLabel(gi: Int, k: Int): CharSequence {
        val head = mainLabel(gi)
        return SpannableString("$head\n$k").apply {
            setSpan(RelativeSizeSpan(0.62f), 0, head.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun mainBackground(color: Int, strokePx: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color); setStroke(strokePx, Color.WHITE)
    }

    private fun copyBackground(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor((color and 0x00FFFFFF) or 0xB3000000.toInt())
        setStroke(dp(2), Color.WHITE, dp(5).toFloat(), dp(3).toFloat())
    }

    private fun createGroup(nx: Float, ny: Float, colorIdx: Int): Group {
        val g = Group(colorIdx)
        groups.add(g)
        val pos = groups.size - 1
        val size = tSizePx()
        val button = TextView(this).apply {
            text = mainLabel(pos)
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = false
            minWidth = size; minHeight = size
            background = mainBackground(colorOf(g), dp(3))
        }
        val (screenW, screenH) = screenSize()
        g.tView = button
        button.alpha = chipAlpha()
        windowManager.addView(
            button,
            overlayParams(
                max(0, (nx * screenW - size / 2f).toInt()),
                max(0, (ny * screenH - size / 2f).toInt()),
                chipsTouchable(g)
            )
        )
        button.setOnTouchListener(dragListener(button, onDragEnd = { persistGroups() }, onDownHandled = { stopIfRepeating() }) { onTPressed(g) })
        return g
    }

    private fun tCenter(g: Group): Pair<Float, Float>? {
        val v = g.tView ?: return null
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return null
        val w = if (v.width > 0) v.width else tSizePx()
        val h = if (v.height > 0) v.height else tSizePx()
        return (p.x + w / 2f) to (p.y + h / 2f)
    }

    private fun relabelAll() {
        groups.forEachIndexed { gi, g ->
            (g.tView as? TextView)?.text = mainLabel(gi)
            g.views.forEachIndexed { k, v -> (v as? TextView)?.text = copyLabel(gi, k + 1) }
        }
    }

    // Small round T chip used in the panel (selector row and quick-press column).
    private fun smallMain(label: String, color: Int, selected: Boolean) = TextView(this).apply {
        text = label; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); gravity = Gravity.CENTER; includeFontPadding = false
        background = mainBackground(color, if (selected) dp(3) else dp(1))
    }

    // Row in the panel: pick which T the next actions apply to, or add a new T.
    private fun rebuildSelector() {
        selectorRow?.let { row ->
            row.removeAllViews()
            groups.forEachIndexed { i, g ->
                row.addView(smallMain(mainLabel(i), colorOf(g), i == selectedGroup).apply {
                    alpha = if (i == selectedGroup) 1f else 0.55f
                    layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                    setOnClickListener { selectedGroup = i; rebuildSelector() }
                })
            }
            if (groups.size < MAX_GROUPS) {
                row.addView(TextView(this).apply {
                    text = "+"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    includeFontPadding = false
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL; setColor(0x22FFFFFF)
                        setStroke(dp(1), 0x99FFFFFF.toInt(), dp(3).toFloat(), dp(2).toFloat())
                    }
                    layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                    setOnClickListener { addGroup() }
                })
            }
        }
        val g = groups.getOrNull(selectedGroup)
        legendView?.text = if (g == null) "" else "المختار: ${mainLabel(selectedGroup)}  •  عدد النسخ: ${g.coords.size}"
        rebuildQuickColumn()
    }

    // While the buttons are hidden from the screen, these chips (under the floating logo) press each T.
    private fun rebuildQuickColumn() {
        val col = quickColumn ?: return
        // Hidden mode leaves ONLY the floating Hayat logo on screen (no extra chips).
        col.removeAllViews()
        col.visibility = View.GONE
    }

    private fun addGroup() {
        if (groups.size >= MAX_GROUPS) {
            Toast.makeText(this, "أقصى عدد من الأزرار هو $MAX_GROUPS", Toast.LENGTH_SHORT).show()
            return
        }
        val (nx, ny) = defaultTPos(groups.size)
        createGroup(nx, ny, (groups.maxOfOrNull { it.colorIdx } ?: -1) + 1)
        selectedGroup = groups.size - 1
        relabelAll()
        rebuildSelector()
        persistGroups()
        Toast.makeText(this, "تمت إضافة زر جديد. حرّكه وأضف له نسخًا", Toast.LENGTH_LONG).show()
    }

    private fun deleteSelectedGroup() {
        if (groups.size <= 1) {
            Toast.makeText(this, "لازم يبقى زر واحد على الأقل", Toast.LENGTH_SHORT).show()
            return
        }
        val g = groups.getOrNull(selectedGroup) ?: return
        clearGroupCopies(g)
        g.tView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        groups.remove(g)
        selectedGroup = 0
        relabelAll()
        rebuildSelector()
        persistGroups()
        Toast.makeText(this, "تم حذف الزر ونسخه", Toast.LENGTH_SHORT).show()
    }

    // ---- Press modes ----
    private fun pressLabel() = when (pressMode) {
        1 -> "نوع الضغط: مطوّل"
        2 -> "نوع الضغط: متكرر سريع"
        else -> "نوع الضغط: نقرة"
    }

    private fun togetherLabel() = if (together) "التزامن: معًا في نفس اللحظة" else "التزامن: تتابع سريع"

    private fun holdMs() = when (pressMode) { 1 -> LONG_PRESS_MS; 2 -> FAST_PRESS_MS; else -> NORMAL_PRESS_MS }

    private fun pressName() = when (pressMode) { 1 -> "مطوّل"; 2 -> "متكرر سريع"; else -> "نقرة" }

    private fun togetherName() = if (together) "معًا" else "تتابع سريع"

    private fun hideName() = if (buttonsHidden) "إظهار الأزرار" else "إخفاء الأزرار"

    private fun computeOutsideTarget(): Boolean {
        val target = getSharedPreferences("tp", 0).getString("target", null)
        return !target.isNullOrBlank() && !TouchAccessibilityService.isTargetForeground
    }

    // The selected app came to the front or left it. Buttons only exist inside that app.
    private fun onTargetForeground() {
        val wasOutside = outsideTarget
        outsideTarget = computeOutsideTarget()
        if (outsideTarget && !wasOutside) {
            if (repeating) {
                repeating = false
                updateLogo()
                Toast.makeText(this, "خرجت من التطبيق فتوقف التكرار", Toast.LENGTH_SHORT).show()
            }
            setMenuOpen(false)
        }
        if (outsideTarget != wasOutside) {
            applyVisibility()
            rebuildQuickColumn()
        }
    }

    private fun updateLogo() { (logoView as? HayatLogoView)?.stopMode = repeating }

    private fun saveModes() {
        getSharedPreferences("tp", 0).edit().putInt("press_mode", pressMode).putBoolean("together", together).apply()
    }

    private fun pressSelected() {
        groups.getOrNull(selectedGroup)?.let { onTPressed(it) }
    }

    // A finger on any T / the logo stops a running repeat immediately (on touch-down, not on release).
    private fun stopIfRepeating(): Boolean {
        if (!repeating) return false
        stopRepeating()
        return true
    }

    // Pressing a T: one tap / one long press, or (fast-repeat mode) start and stop repeating.
    private fun onTPressed(g: Group) {
        if (repeating) { stopRepeating(); return }
        if (busy) return
        if (outsideTarget) return
        if (TouchAccessibilityService.instance == null) {
            Toast.makeText(this, "فعّل خدمة «حياة» من إعدادات إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
            return
        }
        if (tCenter(g) == null) return
        setMenuOpen(false)
        busy = true
        // Only this group's chips ignore touches while its gesture runs, so the taps reach the app underneath.
        activeGroup = g
        refreshTouchability()
        val loop = pressMode == 2
        if (loop) {
            repeating = true
            updateLogo()
            Toast.makeText(this, "بدأ التكرار السريع. المس الشعار الأحمر للإيقاف", Toast.LENGTH_SHORT).show()
        }
        val token = ++runToken
        // The flag change must reach the system before the first gesture, otherwise a tap can land on our own chip.
        handler.postDelayed({
            if (token == runToken) {
                if (loop && !repeating) finishPress() else sendBatch(g, token)
            }
        }, PASS_THROUGH_DELAY_MS)
    }

    private fun clearWatchdog() {
        watchdog?.let { handler.removeCallbacks(it) }
        watchdog = null
    }

    // Sends one gesture. In fast-repeat mode that gesture holds several rounds of taps, so the system is
    // called a few times per second instead of dozens (this is what made the screen freeze before).
    private fun sendBatch(g: Group, token: Int) {
        if (token != runToken) return
        if (outsideTarget) {
            // The target app left the foreground: nothing may be tapped anywhere else on the phone.
            repeating = false
            updateLogo()
            finishPress()
            return
        }
        val service = TouchAccessibilityService.instance
        val main = tCenter(g)
        if (service == null || main == null) { failRun(); return }
        val (taps, lengthMs) = buildBatch(listOf(main) + g.coords.toList())
        var answered = false
        fun answer(completed: Boolean) {
            if (answered || token != runToken) return
            answered = true
            clearWatchdog()
            onBatchDone(g, token, completed)
        }
        clearWatchdog()
        // Safety net in case the system never reports the gesture result.
        val guard = Runnable { answer(true) }
        watchdog = guard
        handler.postDelayed(guard, lengthMs + 1500L)
        val sent = service.dispatchTaps(taps) { completed -> answer(completed) }
        if (!sent) {
            answered = true
            clearWatchdog()
            failRun()
        }
    }

    private fun onBatchDone(g: Group, token: Int, completed: Boolean) {
        if (token != runToken) return
        if (!repeating) { finishPress(); return }
        // A real finger on the screen cancels an injected gesture. When that happens, wait a moment before the
        // next batch so the touch (for example on the stop button) goes through cleanly instead of fighting it.
        val wait = if (completed) 0L else CANCEL_BACKOFF_MS
        handler.postDelayed({
            if (token == runToken) {
                if (repeating) sendBatch(g, token) else finishPress()
            }
        }, wait)
    }

    private fun failRun() {
        repeating = false
        updateLogo()
        finishPress()
        Toast.makeText(this, "تعذر إرسال اللمسات. تأكد من تفعيل خدمة «حياة».", Toast.LENGTH_LONG).show()
    }

    private fun finishPress() {
        runToken++
        clearWatchdog()
        busy = false
        activeGroup = null
        refreshTouchability()
    }

    private fun stopRepeating() {
        if (!repeating) return
        repeating = false
        updateLogo()
        Toast.makeText(this, "تم إيقاف التكرار", Toast.LENGTH_SHORT).show()
    }

    // Builds the taps of ONE gesture: the T plus its copies. Taps use strokes with their own start times, so a
    // whole sequence (or several fast rounds) is delivered in a single call.
    private fun buildBatch(all: List<Pair<Float, Float>>): Pair<List<TouchAccessibilityService.Tap>, Long> {
        val maxStrokes = TouchAccessibilityService.maxStrokes()
        if (all.size > maxStrokes && !capWarned) {
            capWarned = true
            Toast.makeText(this, "الحد الأقصى $maxStrokes نقطة في المرة الواحدة، والزائد لن يُنفَّذ", Toast.LENGTH_LONG).show()
        }
        // Gesture coordinates must not be negative (a chip dragged half off-screen would crash otherwise).
        val points = all.take(maxStrokes).map { (x, y) -> max(0f, x) to max(0f, y) }
        val press = holdMs()
        val loop = pressMode == 2
        val roundGap = if (loop) FAST_GAP_MS else 0L
        val perRound = points.size
        val taps = ArrayList<TouchAccessibilityService.Tap>()
        var roundStart = 0L
        var end = 0L
        do {
            points.forEachIndexed { i, (x, y) ->
                // together: every point starts at the same instant; otherwise one after another, a few ms apart.
                val start = if (together) roundStart else roundStart + i * (press + SEQ_GAP_MS)
                taps.add(TouchAccessibilityService.Tap(x, y, start, press))
                end = max(end, start + press)
            }
            roundStart = end + roundGap
        } while (loop && taps.size + perRound <= maxStrokes && roundStart + press <= BATCH_MAX_MS)
        return taps to end
    }

    private fun clearGroupCopies(g: Group) {
        g.views.forEach { try { windowManager.removeView(it) } catch (_: Exception) { } }
        g.views.clear()
        g.coords.clear()
    }

    private fun clearCopies() {
        val g = groups.getOrNull(selectedGroup) ?: return
        clearGroupCopies(g)
        persistGroups()
        rebuildSelector()
        Toast.makeText(this, "تم حذف نسخ الزر المختار", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        val prefs = getSharedPreferences("tp", 0)
        pressMode = prefs.getInt("press_mode", 0).coerceIn(0, 2)
        together = prefs.getBoolean("together", true)
        buttonsHidden = prefs.getBoolean("buttons_hidden", false)
        outsideTarget = computeOutsideTarget()
        TouchAccessibilityService.foregroundListener = { onTargetForeground() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_PROJECTION -> startProjection(intent)
            ACTION_SHOW_PANEL -> showPanel()
            ACTION_REFRESH_POINTS -> refreshPointViews()
            ACTION_RESTORE_OVERLAYS -> restoreOverlays()
        }
        return START_STICKY
    }

    private fun startProjection(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") (intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
        if (resultCode != Activity.RESULT_OK || data == null) return
        startForeground(notificationId, buildNotification(), if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection?.stop()
        projection = manager.getMediaProjection(resultCode, data)
        projectionActive = projection != null
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                releaseCaptureResources()
                projection = null
                projectionActive = false
            }
        }, handler)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("touchpilot_capture", "حياة", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "touchpilot_capture").setContentTitle("حياة").setContentText("إذن التقاط الشاشة نشط").setSmallIcon(R.drawable.ic_stat_hayat).setContentIntent(pending).build()
        else Notification.Builder(this).setContentTitle("حياة").setContentText("إذن التقاط الشاشة نشط").setSmallIcon(R.drawable.ic_stat_hayat).build()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    // NOT_FOCUSABLE: the overlay must not steal focus from the target app.
    // NOT_TOUCH_MODAL: touches outside the overlay must reach the app behind it.
    private fun baseFlags() = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    private fun overlayParams(x: Int, y: Int, touchable: Boolean = true, windowAlpha: Float = 0.75f): WindowManager.LayoutParams {
        var flags = baseFlags()
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y; alpha = windowAlpha
            // Without this, on notched/punch-hole screens the window is pushed below the cutout,
            // so the chip is drawn lower than the coordinates we send to dispatchGesture.
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // Real display size (including system bars) so the screenshot, the saved normalized
    // points and the gesture coordinates all use the same reference.
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = windowManager.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val m = android.util.DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private fun cleanOldCaptures() {
        getExternalFilesDir(null)?.listFiles { f -> f.name.startsWith("capture-") && f.name.endsWith(".png") }
            ?.forEach { try { it.delete() } catch (_: Exception) { } }
    }

    private fun copyChip(label: CharSequence, color: Int) = TextView(this).apply {
        text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); gravity = Gravity.CENTER
        includeFontPadding = false; setLineSpacing(0f, 0.9f)
        minWidth = dp(46); minHeight = dp(46)
        background = copyBackground(color)
    }

    private fun applyVisibility() {
        panel?.alpha = if (overlaysHidden || outsideTarget) 0f else 1f
        chipViews().forEach { it.alpha = chipAlpha() }
        refreshTouchability()
    }

    private fun setOverlaysHidden(hidden: Boolean) {
        // alpha instead of INVISIBLE: the overlay windows stay alive, which Android requires
        // for the app to be allowed to open the editor from the background.
        overlaysHidden = hidden
        applyVisibility()
    }

    // Hide the look of every T and copy (they stay where they are) while the floating panel stays.
    // Hidden buttons also stop catching touches; the quick chips under the logo press each T instead.
    private fun setButtonsHidden(hidden: Boolean) {
        buttonsHidden = hidden
        persistGroups()
        getSharedPreferences("tp", 0).edit().putBoolean("buttons_hidden", hidden).apply()
        applyVisibility()
        rebuildQuickColumn()
        hideValueView?.apply { text = hideName(); setTextColor(if (hidden) Brand.MINT else Color.WHITE) }
        panel?.postDelayed({ keepPanelOnScreen() }, 120L)
        Toast.makeText(
            this,
            if (hidden) "أُخفيت الأزرار. المس الشعار للتنفيذ، واضغط عليه مطولًا لفتح القائمة" else "ظهرت الأزرار في أماكنها",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun setNotTouchable(view: View, notTouchable: Boolean) {
        val p = view.layoutParams as? WindowManager.LayoutParams ?: return
        val flags = baseFlags() or (if (notTouchable) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
        if (p.flags == flags) return
        p.flags = flags
        try { windowManager.updateViewLayout(view, p) } catch (_: Exception) { }
    }

    private fun refreshTouchability() {
        panel?.let { setNotTouchable(it, overlaysHidden || outsideTarget) }
        groups.forEach { g ->
            val block = !chipsTouchable(g)
            g.tView?.let { setNotTouchable(it, block) }
            g.views.forEach { setNotTouchable(it, block) }
        }
    }

    private var menu: View? = null

    private fun setMenuOpen(open: Boolean) {
        menu?.visibility = if (open) View.VISIBLE else View.GONE
        val box = panel ?: return
        try { windowManager.updateViewLayout(box, box.layoutParams) } catch (_: Exception) { }
        box.postDelayed({ keepPanelOnScreen() }, 120L)
    }

    // The open menu is taller than the logo, so nudge the panel back inside the screen.
    private fun keepPanelOnScreen() {
        val box = panel ?: return
        val p = box.layoutParams as? WindowManager.LayoutParams ?: return
        val (w, h) = screenSize()
        val nx = p.x.coerceIn(0, max(0, w - box.width))
        val ny = p.y.coerceIn(0, max(0, h - box.height))
        if (nx != p.x || ny != p.y) {
            p.x = nx; p.y = ny
            try { windowManager.updateViewLayout(box, p) } catch (_: Exception) { }
        }
    }

    private fun toggleMenu() = setMenuOpen(menu?.visibility != View.VISIBLE)

    private class Tile(val root: LinearLayout, val value: TextView)

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false, gravity: Int = Gravity.START) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); this.gravity = gravity
        if (bold) typeface = Typeface.DEFAULT_BOLD
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }

    private fun sectionTitle(t: String) = label(t, 11f, Brand.MINT, true).apply { setPadding(dp(4), dp(10), dp(4), dp(3)) }

    // A settings tile: small caption on top, the action/value in bold below.
    private fun tile(caption: String, text: String, color: Int, onClick: (Tile) -> Unit): Tile {
        val value = TextView(this).apply {
            this.text = text; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 1
        }
        val cap = TextView(this).apply {
            this.text = caption; textSize = 10f; setTextColor(0xFFB4C6D8.toInt()); gravity = Gravity.CENTER; maxLines = 1
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8)); minimumHeight = dp(54)
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }
            isClickable = true
            addView(cap); addView(value)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        }
        val t = Tile(root, value)
        root.setOnClickListener { onClick(t) }
        return t
    }

    private fun tileRow(vararg tiles: Tile) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        tiles.forEach { addView(it.root) }
    }

    // Keeps the menu usable on short screens (landscape): it scrolls instead of running off the screen.
    private inner class MaxHeightScroll : ScrollView(this@TouchService) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val maxH = (screenSize().second * 0.8f).toInt() - dp(72)
            super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
        }
    }

    private fun showPanel() {
        if (panel != null) { panel?.visibility = View.VISIBLE; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val logo = HayatLogoView(this, 56)
        logoView = logo
        box.addView(logo, LinearLayout.LayoutParams(-2, -2))

        // Quick-press chips: only shown while the T buttons are hidden from the screen.
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable().apply { setColor(0xE60E1A27.toInt()); cornerRadius = dp(22).toFloat() }
        }
        quickColumn = quick
        box.addView(quick, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6); gravity = Gravity.CENTER_HORIZONTAL })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(10), dp(10), dp(12))
        }
        val scroll = MaxHeightScroll().apply {
            visibility = View.GONE
            isVerticalScrollBarEnabled = false
            background = GradientDrawable().apply { setColor(Brand.CARD); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
            clipToOutline = true
            addView(card)
        }
        menu = scroll
        box.addView(scroll, LinearLayout.LayoutParams(dp(272), -2).apply { topMargin = dp(6) })

        card.addView(label("حياة", 20f, Color.WHITE, true))
        card.addView(label("لوحة التحكم", 11f, Brand.MUTED).apply { setPadding(0, 0, 0, dp(2)) })

        // Section 1: which button the actions below apply to.
        card.addView(sectionTitle("الأزرار"))
        val selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        selectorRow = selector
        card.addView(selector, LinearLayout.LayoutParams(-1, -2))
        val legend = label("", 11f, Brand.MUTED).apply { setPadding(dp(4), dp(2), dp(4), 0) }
        legendView = legend
        card.addView(legend)
        card.addView(tileRow(
            tile("الزر المختار", "تنفيذ الآن", 0xFF14735A.toInt()) { pressSelected() }
        ))

        // Section 2: copies of the selected button.
        card.addView(sectionTitle("النسخ"))
        val countBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(0, dp(6), 0, dp(2))
        }
        countBox.addView(label("كم نسخة تريد إضافتها؟", 12f, Color.WHITE, gravity = Gravity.CENTER))
        val countRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (n in 1..6) {
            countRow.addView(TextView(this).apply {
                text = n.toString(); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE); gravity = Gravity.CENTER; includeFontPadding = false
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF14735A.toInt()) }
                layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(2), dp(4), dp(2), dp(2)) }
                setOnClickListener { countBox.visibility = View.GONE; addTouchCopies(n) }
            })
        }
        countBox.addView(countRow)
        card.addView(tileRow(
            tile("الزر المختار", "إضافة نسخ", 0xFF14735A.toInt()) {
                countBox.visibility = if (countBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            },
            tile("الزر المختار", "حذف النسخ", 0xFF4A2F45.toInt()) { setMenuOpen(false); clearCopies() }
        ))
        card.addView(countBox)

        // Section 3: how a press behaves.
        card.addView(sectionTitle("الضغط"))
        card.addView(tileRow(
            tile("نوع الضغط", pressName(), Brand.TILE) { t ->
                pressMode = (pressMode + 1) % 3
                saveModes()
                t.value.text = pressName()
                Toast.makeText(this, pressLabel(), Toast.LENGTH_SHORT).show()
            },
            tile("التزامن", togetherName(), Brand.TILE) { t ->
                together = !together
                saveModes()
                t.value.text = togetherName()
                Toast.makeText(this, togetherLabel(), Toast.LENGTH_SHORT).show()
            }
        ))

        // Section 4: screen + tools.
        card.addView(sectionTitle("الشاشة والأدوات"))
        val hideTile = tile("على الشاشة", hideName(), Brand.TILE) { setButtonsHidden(!buttonsHidden) }
        hideValueView = hideTile.value
        hideTile.value.setTextColor(if (buttonsHidden) Brand.MINT else Color.WHITE)
        card.addView(tileRow(
            hideTile,
            tile("لقطة الشاشة", "تحديد النقاط", Brand.TILE) { setMenuOpen(false); captureGroup = selectedGroup; captureScreen() }
        ))
        card.addView(tileRow(
            tile("الزر المختار", "حذف الزر", 0xFF4A2F45.toInt()) { setMenuOpen(false); deleteSelectedGroup() },
            tile("اللوحة", "إغلاق", 0xFF3A3F4A.toInt()) { stopSelf() }
        ))

        panel = box
        outsideTarget = computeOutsideTarget()
        // The panel is its own window and never has to let touches through, so it can be fully opaque.
        windowManager.addView(box, overlayParams(24, 170, true, 1f))
        logo.setOnTouchListener(dragListener(box, onDownHandled = { stopIfRepeating() }, onLongPress = { if (buttonsHidden) toggleMenu() }) {
            if (buttonsHidden) pressSelected() else toggleMenu()
        })
        loadGroups()
        applyVisibility()
    }

    // onDownHandled runs on touch-down; when it returns true the whole touch is consumed (used to stop a repeat).
    // onLongPress (optional) fires after the system long-press time if the finger has not moved.
    private fun dragListener(
        view: View,
        onDragEnd: () -> Unit = {},
        onDownHandled: () -> Boolean = { false },
        onLongPress: (() -> Unit)? = null,
        onTap: () -> Unit
    ): View.OnTouchListener {
        var downX = 0f; var downY = 0f; var originX = 0; var originY = 0; var dragged = false
        var swallowed = false
        var longFired = false
        val longRunnable = Runnable { if (!dragged) { longFired = true; onLongPress?.invoke() } }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        return View.OnTouchListener { _, event ->
            val params = view.layoutParams as WindowManager.LayoutParams
            if (event.action == MotionEvent.ACTION_DOWN) swallowed = onDownHandled()
            if (swallowed) {
                if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) swallowed = false
                true
            } else when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; originX = params.x; originY = params.y
                    dragged = false; longFired = false
                    if (onLongPress != null) handler.postDelayed(longRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX; val dy = event.rawY - downY
                    if (!dragged && kotlin.math.hypot(dx, dy) > slop) { dragged = true; handler.removeCallbacks(longRunnable) }
                    if (dragged) {
                        // Stay fully on screen, so where the chip is drawn is exactly where it taps.
                        val (sw, sh) = screenSize()
                        params.x = (originX + dx.toInt()).coerceIn(0, max(0, sw - view.width))
                        params.y = (originY + dy.toInt()).coerceIn(0, max(0, sh - view.height))
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRunnable)
                    if (longFired) { /* the long press already handled this touch */ }
                    else if (!dragged) onTap() else onDragEnd()
                    true
                }
                else -> { handler.removeCallbacks(longRunnable); true }
            }
        }
    }

    private fun addTouchCopies(count: Int) {
        val g = groups.getOrNull(selectedGroup) ?: return
        val center = tCenter(g) ?: return
        val (screenW, screenH) = screenSize()
        val gap = dp(64).toFloat()
        val margin = dp(30).toFloat()
        // Copies fan out next to their own T, towards the middle of the screen.
        val dir = if (center.first < screenW / 2f) 1f else -1f
        for (i in 0 until count) {
            // Each new copy gets its own free slot (3 per row), so copies added later never
            // land on top of copies that already exist.
            val slot = g.coords.size
            val x = (center.first + dir * gap * ((slot % 3) + 1)).coerceIn(margin, screenW - margin)
            val y = (center.second + gap * (slot / 3)).coerceIn(margin, screenH - margin)
            addCopy(g, x, y)
        }
        persistGroups()
        rebuildSelector()
        Toast.makeText(this, "تمت إضافة $count نسخة", Toast.LENGTH_SHORT).show()
    }

    private fun addCopy(g: Group, x: Float, y: Float) {
        g.coords.add(x to y)
        val view = copyChip(copyLabel(groups.indexOf(g), g.coords.size), colorOf(g))
        g.views.add(view)
        view.alpha = chipAlpha()
        windowManager.addView(view, overlayParams(max(0, x.toInt() - dp(23)), max(0, y.toInt() - dp(23)), chipsTouchable(g)))
        view.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { if (repeating) stopRepeating(); sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val (sw, sh) = screenSize()
                        p.x=(ox+(e.rawX-sx).toInt()).coerceIn(0, max(0, sw - v.width))
                        p.y=(oy+(e.rawY-sy).toInt()).coerceIn(0, max(0, sh - v.height))
                        windowManager.updateViewLayout(v,p)
                        val idx=g.views.indexOf(v)
                        if (idx>=0) g.coords[idx]=p.x+v.width/2f to p.y+v.height/2f
                        return true
                    }
                    MotionEvent.ACTION_UP -> { persistGroups(); return true }
                }
                return false
            }
        })
    }

    // Older versions saved one T position plus a flat list of points. Those become the first group.
    private fun loadPointsInto(g: Group) {
        val raw = getSharedPreferences("tp", 0).getString("points", null) ?: return
        try {
            val array = JSONArray(raw)
            val (screenW, screenH) = screenSize()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                addCopy(g, item.getDouble("x").toFloat() * screenW, item.getDouble("y").toFloat() * screenH)
            }
        } catch (_: Exception) { }
    }

    private fun loadGroups() {
        val prefs = getSharedPreferences("tp", 0)
        val (screenW, screenH) = screenSize()
        val raw = prefs.getString("groups", null)
        if (raw != null) {
            try {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val (dx, dy) = defaultTPos(i)
                    val g = createGroup(
                        o.optDouble("tx", dx.toDouble()).toFloat(),
                        o.optDouble("ty", dy.toDouble()).toFloat(),
                        o.optInt("c", i)
                    )
                    val copies = o.optJSONArray("copies")
                    if (copies != null) {
                        for (k in 0 until copies.length()) {
                            val item = copies.getJSONObject(k)
                            addCopy(g, item.getDouble("x").toFloat() * screenW, item.getDouble("y").toFloat() * screenH)
                        }
                    }
                }
            } catch (_: Exception) { }
        }
        if (groups.isEmpty()) {
            val g = createGroup(prefs.getFloat("t_x", 0.8f), prefs.getFloat("t_y", 0.5f), 0)
            loadPointsInto(g)
            persistGroups()
        }
        selectedGroup = 0
        relabelAll()
        rebuildSelector()
    }

    // The screenshot editor saves its points under "points": they become the copies of the T that
    // was selected when the screenshot was started.
    private fun refreshPointViews() {
        panel?.visibility = View.VISIBLE
        val g = groups.getOrNull(captureGroup) ?: groups.firstOrNull()
        if (g != null) {
            clearGroupCopies(g)
            loadPointsInto(g)
            persistGroups()
        }
        rebuildSelector()
        restoreOverlays()
    }

    private fun persistGroups() {
        val (screenW, screenH) = screenSize()
        val array = JSONArray()
        groups.forEach { g ->
            val o = org.json.JSONObject()
            val c = tCenter(g)
            if (c != null) {
                o.put("tx", (c.first / screenW).toDouble())
                o.put("ty", (c.second / screenH).toDouble())
            }
            o.put("c", g.colorIdx)
            val copies = JSONArray()
            g.coords.forEach { (x, y) ->
                copies.put(org.json.JSONObject().put("x", (x / screenW).toDouble()).put("y", (y / screenH).toDouble()))
            }
            o.put("copies", copies)
            array.put(o)
        }
        getSharedPreferences("tp", 0).edit().putString("groups", array.toString()).apply()
    }

    private fun captureScreen() {
        if (projection == null) {
            Toast.makeText(this, "فعّل التقاط الشاشة من التطبيق الرئيسي أولاً", Toast.LENGTH_LONG).show()
            return
        }
        // Hide controls so the screenshot is a clean view of the target app.
        setOverlaysHidden(true)
        handler.postDelayed({
            try {
                val dm = resources.displayMetrics
                val (screenW, screenH) = screenSize()
                try { imageReader?.close() } catch (_: Exception) { }
                imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
                if (virtualDisplay == null) {
                    virtualDisplay = projection?.createVirtualDisplay(
                        "TouchPilotCapture", screenW, screenH, dm.densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, handler
                    )
                } else {
                    virtualDisplay?.setSurface(imageReader?.surface)
                }
                imageReader?.setOnImageAvailableListener({ reader ->
                    val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                    try {
                        val plane = image.planes[0]
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * image.width
                        val padded = Bitmap.createBitmap(
                            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
                        )
                        padded.copyPixelsFromBuffer(plane.buffer)
                        val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                        padded.recycle()
                        cleanOldCaptures()
                        val file = File(getExternalFilesDir(null), "capture-${System.currentTimeMillis()}.png")
                        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        bitmap.recycle()
                        virtualDisplay?.setSurface(null)
                        try { imageReader?.close() } catch (_: Exception) { }
                        imageReader = null
                        val editor = Intent(this, PointEditorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        editor.putExtra("image_path", file.absolutePath)
                        try {
                            startActivity(editor)
                        } catch (e: Exception) {
                            Toast.makeText(this, "تعذر فتح المحرر: ${e.message}", Toast.LENGTH_LONG).show()
                            restoreOverlays()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "فشل حفظ الصورة: ${e.message}", Toast.LENGTH_LONG).show()
                        detachCaptureReader()
                        restoreOverlays()
                    } finally { image.close() }
                }, handler)
                handler.postDelayed({
                    if (imageReader != null) {
                        Toast.makeText(this, "لم تصل صورة من النظام. جرّب مرة أخرى.", Toast.LENGTH_LONG).show()
                        detachCaptureReader(); restoreOverlays()
                    }
                }, 2500)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر التقاط الشاشة: ${e.message}", Toast.LENGTH_LONG).show()
                detachCaptureReader(); restoreOverlays()
            }
        }, 250)
    }

    private fun restoreOverlays() {
        setOverlaysHidden(false)
        allOverlays().forEach { it.visibility = View.VISIBLE }
    }

    private fun detachCaptureReader() {
        try { virtualDisplay?.setSurface(null) } catch (_: Exception) { }
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
    }

    private fun releaseCaptureResources() {
        detachCaptureReader()
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        repeating = false
        busy = false
        activeGroup = null
        watchdog = null
        TouchAccessibilityService.foregroundListener = null
        releaseCaptureResources()
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        projectionActive = false
        allOverlays().forEach { try { windowManager.removeView(it) } catch (_: Exception) { } }
        groups.clear()
        panel = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        // True while a screen-capture permission is held; read by the main screen to show its status.
        @Volatile var projectionActive = false
        private const val MAX_GROUPS = 5
        // Press timing (ms). Fast repeat = 30 ms touch + 20 ms pause = about 20 taps per second per point.
        private const val NORMAL_PRESS_MS = 50L
        private const val LONG_PRESS_MS = 1200L
        private const val FAST_PRESS_MS = 30L
        private const val FAST_GAP_MS = 20L
        private const val SEQ_GAP_MS = 12L           // spacing between points when simultaneous mode is off
        private const val BATCH_MAX_MS = 400L        // longest fast-repeat gesture, so stopping stays instant
        private const val PASS_THROUGH_DELAY_MS = 120L
        private const val CANCEL_BACKOFF_MS = 350L
        private val GROUP_COLORS = intArrayOf(
            0xFFE64A79.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFB8C00.toInt(), 0xFF8E24AA.toInt(), 0xFF00ACC1.toInt()
        )
        const val ACTION_START_PROJECTION = "com.touchpilot.START_PROJECTION"
        const val ACTION_SHOW_PANEL = "com.touchpilot.SHOW_PANEL"
        const val ACTION_REFRESH_POINTS = "com.touchpilot.REFRESH_POINTS"
        const val ACTION_RESTORE_OVERLAYS = "com.touchpilot.RESTORE_OVERLAYS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
    }
}
