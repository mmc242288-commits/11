package com.touchpilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class TouchAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        // Only window transitions should change the foreground-target state.
        // Content/overlay events can originate from TouchPilot itself.
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val packageName = e.packageName?.toString() ?: return
        // TouchPilot's own overlays/editor must not flip the state. Only its main screen counts as "left the target".
        if (packageName == this.packageName) {
            if (e.className?.toString() == MainActivity::class.java.name) updateForeground(false)
            return
        }
        // Notification shade / volume panel / system bars: the target app does not send a new event when they
        // close, so reacting to them would leave the buttons hidden for good.
        if (packageName == "com.android.systemui") return
        // The keyboard opening emits a window event from the IME package. Treating that as
        // "target left the foreground" paused the run until the target changed window again.
        if (isImePackage(packageName)) return
        val target = getSharedPreferences("tp", 0).getString("target", null)
        updateForeground(!target.isNullOrBlank() && packageName == target)
    }

    private fun isImePackage(pkg: String): Boolean = try {
        val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
            as android.view.inputmethod.InputMethodManager
        imm.enabledInputMethodList.any { it.packageName == pkg }
    } catch (_: Exception) { false }

    override fun onInterrupt() { }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        updateForeground(false)
        super.onDestroy()
    }

    /** One tap: where, when it starts inside the gesture and how long it lasts. */
    class Tap(val x: Float, val y: Float, val startMs: Long, val durationMs: Long)

    /**
     * Sends many taps as ONE gesture. Every tap is its own stroke with its own start time, so taps with the
     * same start time are simultaneous (multi-touch) and different start times give a quick sequence.
     * onResult(true) = the gesture finished, onResult(false) = it was cancelled (for example by a real touch).
     */
    fun dispatchTaps(taps: List<Tap>, onResult: (Boolean) -> Unit): Boolean {
        if (taps.isEmpty()) return false
        return try {
            val builder = GestureDescription.Builder()
            taps.take(maxStrokes()).forEach { t ->
                // A zero-length moveTo-only path is rejected on some Android builds.
                // A same-coordinate line produces a proper tap/hold stroke.
                val path = Path().apply { moveTo(t.x, t.y); lineTo(t.x, t.y) }
                builder.addStroke(
                    GestureDescription.StrokeDescription(path, t.startMs.coerceAtLeast(0L), t.durationMs.coerceIn(1L, 60000L))
                )
            }
            val callback = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { onResult(true) }
                override fun onCancelled(gestureDescription: GestureDescription?) { onResult(false) }
            }
            dispatchGesture(builder.build(), callback, null)
        } catch (_: Exception) { false }
    }

    companion object {
        @Volatile var instance: TouchAccessibilityService? = null
        @Volatile var isTargetForeground: Boolean = false

        /** Called (on the main thread) whenever the selected target app enters or leaves the foreground. */
        @Volatile var foregroundListener: ((Boolean) -> Unit)? = null

        fun updateForeground(value: Boolean) {
            if (isTargetForeground == value) return
            isTargetForeground = value
            foregroundListener?.invoke(value)
        }

        /** The most strokes (simultaneous or sequential taps) the system accepts in one gesture. */
        fun maxStrokes(): Int = try { GestureDescription.getMaxStrokeCount().coerceAtLeast(1) } catch (_: Throwable) { 10 }
    }
}
